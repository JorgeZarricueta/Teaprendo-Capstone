self.assetsManifest = {
  "version": "va3cr8pp",
  "assets": [
    {
      "hash": "sha256-hs5ucoDFu1YYCgXAE/Pzl2ci9RtXwisSrMUDPobOg0E=",
      "url": "TEAprendo.Client.styles.css"
    },
    {
      "hash": "sha256-jG9J70J7TtOrMBWM7jjeQAS39juTl4bJpRXGN6fhQlg=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.4w3z20tuqk.wasm"
    },
    {
      "hash": "sha256-LM04i1jy+LgVHqU5bGAbOGfq3sokEYpY33rzzuaadlw=",
      "url": "_framework/Microsoft.AspNetCore.Components.0z8r7oen0q.wasm"
    },
    {
      "hash": "sha256-JvMWXAOhDPo+zB8yHSWOEHEeT9/fcwZCQDwAxCPHXlg=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.y5xx1fx6r9.wasm"
    },
    {
      "hash": "sha256-HmTn6qpK4NWMdGwHU6HJ/nunn6y5o3uCm5V7+7M0480=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.aeyv0fw1i0.wasm"
    },
    {
      "hash": "sha256-CH3a6skUDM+VD0EXPna4MFUS+MAICki7cC71hQWVQhQ=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.0279vibpf3.wasm"
    },
    {
      "hash": "sha256-dJZQlLCWV8HxVn+VLwiM3zh+2v2/BoHWNtaWvNqMdS8=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.s8loo8n9nc.wasm"
    },
    {
      "hash": "sha256-zvHf27ahVxlI2AFXaxGFeC6gsmk+KU/jayZSX/aTduc=",
      "url": "_framework/Microsoft.CSharp.6q6v6mynmi.wasm"
    },
    {
      "hash": "sha256-A8e6zZwhOqf7lDQqbbCYcAUv4wGE9aQxOo4WyYxR//0=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.99zm1jdh75.lib.module.js"
    },
    {
      "hash": "sha256-RLtDESON1MfC+2wOqFrpt2gSBfHk0qNFaTbHuAp8feE=",
      "url": "_framework/Microsoft.DotNet.HotReload.WebAssembly.Browser.ccsptreuls.wasm"
    },
    {
      "hash": "sha256-JHlpaYwiFqUQsagYTswarGEumsuA2+B1FVlqNZlkfzo=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.0hgjfwn1mu.wasm"
    },
    {
      "hash": "sha256-kYMVPmvUG8KS2TX3Mg+rKrWefG5VEnAfiPzaK7KlQgA=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.3jotnx07h9.wasm"
    },
    {
      "hash": "sha256-+UDJGDD1aV0uVsFf4YjM9MH7I+tb9CFJD1YfH0g3Wrc=",
      "url": "_framework/Microsoft.Extensions.Configuration.FileExtensions.pk5rwjur7z.wasm"
    },
    {
      "hash": "sha256-/pcKpSD6mBNjNREATQAkUv3Zf4H3LyuzGTLN4s679vs=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.m2qoahxjgt.wasm"
    },
    {
      "hash": "sha256-PSnciWnNXMK//gr+udb0elW/q8iLCYYXWR/eTBtp2Qk=",
      "url": "_framework/Microsoft.Extensions.Configuration.f1h675694q.wasm"
    },
    {
      "hash": "sha256-ltrV7AuG5saT+kD92VT0248FL6wL5t4JuEI87HjoAS0=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.6lng263cnf.wasm"
    },
    {
      "hash": "sha256-lBKCOBVvAMXlOis/l1+M33Cn6tKVgMg3bdHHrXj/a7Q=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.0774chwaiw.wasm"
    },
    {
      "hash": "sha256-MSDiTWDEv1a00OkP+a6/SwW6ekKoVPA746sMdaFKA8E=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.ne0bxy880x.wasm"
    },
    {
      "hash": "sha256-fucavrV2xP++Dn/l5sNeH6M5xt1BBtbTDZQyLuSiikg=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.i4mi4tc4vw.wasm"
    },
    {
      "hash": "sha256-K+bL2FtukXzpFJCa3zncXjGqgfdxO9pnlf2wde9g3UQ=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Abstractions.pzlq0qczlw.wasm"
    },
    {
      "hash": "sha256-NN9DfS/PNCg9pw+/XvOTZ7d3DxETLJ3DiLjZ2kOmL+0=",
      "url": "_framework/Microsoft.Extensions.FileProviders.Physical.gp2mcne8f6.wasm"
    },
    {
      "hash": "sha256-Qz96yGM90nRLDI1XCXF6mre4CdDEiJLgnGOrszdMH2s=",
      "url": "_framework/Microsoft.Extensions.FileSystemGlobbing.bmq20vrvql.wasm"
    },
    {
      "hash": "sha256-ZDFBw3KioO2quJW2njJ9xbLnWgU/FrChBN1BjbHEoG8=",
      "url": "_framework/Microsoft.Extensions.Http.0nix2wjov7.wasm"
    },
    {
      "hash": "sha256-Ufg8lS+p6OZ00WWMeQqTGKA/IS8O9sECUPEuGvM5WA4=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.9iwncqwny2.wasm"
    },
    {
      "hash": "sha256-o/gQAuPMwH+rbawuWz6xWOq1Ci5tN52xGlVFOOwBtl4=",
      "url": "_framework/Microsoft.Extensions.Logging.ptjwzqfpka.wasm"
    },
    {
      "hash": "sha256-67yI4vesQjof/F/jpJtEmH6kmQ5HDkvaYPoH2YpZiPk=",
      "url": "_framework/Microsoft.Extensions.Options.ConfigurationExtensions.3i6cpeqz4b.wasm"
    },
    {
      "hash": "sha256-JoxbwT+ZaOtmIRkTmwFOip/K7uoJJpFRzW56h6XkRpQ=",
      "url": "_framework/Microsoft.Extensions.Options.i52tw7ob6b.wasm"
    },
    {
      "hash": "sha256-5uk1If5BOfuRl+IDKfk3cqyIIvd49ThDPGjllxw4z10=",
      "url": "_framework/Microsoft.Extensions.Primitives.iq6oe4oszz.wasm"
    },
    {
      "hash": "sha256-TPHp2vON5qjVdsb6ZuDh0rxu/FCFbB3r2IMcQHThpfo=",
      "url": "_framework/Microsoft.Extensions.Validation.w1rf8w9vwy.wasm"
    },
    {
      "hash": "sha256-tLy3qNrIC+jAb4i4SjHRuKzQlxxUQCDHYV6b4oUjEV4=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.4u1gumewbn.wasm"
    },
    {
      "hash": "sha256-SZIr25HLqaeri9f5UuJpYtWWdLH4iSpFr5RmCLj3CAI=",
      "url": "_framework/Microsoft.JSInterop.r7i6scgm0q.wasm"
    },
    {
      "hash": "sha256-AZ1OBnZZieuRTiDGO1izE2Hj+dIr0EJKAZci6Ip77ZA=",
      "url": "_framework/Microsoft.VisualBasic.Core.7ahatwz856.wasm"
    },
    {
      "hash": "sha256-cIXni6yabmZg2CT9PfUwYJh4QXAikeZhlBhiKNb90e4=",
      "url": "_framework/Microsoft.VisualBasic.sphnc8qe37.wasm"
    },
    {
      "hash": "sha256-n0FdKoueatHa5nv8Parg79didiuVV4i9dXltgpW8dQg=",
      "url": "_framework/Microsoft.Win32.Primitives.x8i8s5qlfi.wasm"
    },
    {
      "hash": "sha256-D7z0gQYE2qYwzCqHrxaeU1ONTQE4d9nrxWJi9SyjpPs=",
      "url": "_framework/Microsoft.Win32.Registry.vw7gs5u6x3.wasm"
    },
    {
      "hash": "sha256-jyY+qefL/Zi4vaVu0D7Y7ZM+LpOdtOuuaz2zaVteAKw=",
      "url": "_framework/System.9immaprbgt.wasm"
    },
    {
      "hash": "sha256-zWwDUGTwmdAPAg/wyxnicWnEIbHIRhP5a0zbwQPvCxE=",
      "url": "_framework/System.AppContext.tcwsqw4zp2.wasm"
    },
    {
      "hash": "sha256-tOllShg6BTGCSxAMEiFJZnBzBper74Ms9lzhmEVuJJU=",
      "url": "_framework/System.Buffers.wv1fr9u78z.wasm"
    },
    {
      "hash": "sha256-PpV2WEqeayibcyObR8Epqg1/MpfRS5mEOBUO3z32Vh0=",
      "url": "_framework/System.Collections.Concurrent.mjcda8szaq.wasm"
    },
    {
      "hash": "sha256-atEBwz5tJz7oy0K/xfppy/nEjzFsGcCEcRJ+zhf8T9I=",
      "url": "_framework/System.Collections.Immutable.uynhbcg8xd.wasm"
    },
    {
      "hash": "sha256-SRkmsNF3uN58PqYIojSfut6VHMqM685aGpX1WN2Xo6w=",
      "url": "_framework/System.Collections.NonGeneric.lxlhsh57kt.wasm"
    },
    {
      "hash": "sha256-GkpbVQluCXi10nHKQPgEm8BO3UbKfyXRY+L8dxB7rB8=",
      "url": "_framework/System.Collections.Specialized.m4ce5na42h.wasm"
    },
    {
      "hash": "sha256-INftXL/eX4gvbC6W9jVLm+Dik2Qo+zrFT642kjjaKJ8=",
      "url": "_framework/System.Collections.ggdo1btk42.wasm"
    },
    {
      "hash": "sha256-9hZsG9bVQPQITjVg++HGKgFy1dTaS4dh/BfUzMujzXM=",
      "url": "_framework/System.ComponentModel.Annotations.6kamo06ruz.wasm"
    },
    {
      "hash": "sha256-844msnT37yyqsutolJI3McEBG0NGUSUmEmIHwX8cWS8=",
      "url": "_framework/System.ComponentModel.DataAnnotations.xbmwog2f1v.wasm"
    },
    {
      "hash": "sha256-pjqbMZvq40M0wwGxtsMzv6R1FbhvtZrg56PFuZCSJI8=",
      "url": "_framework/System.ComponentModel.EventBasedAsync.eqv8o4kw6a.wasm"
    },
    {
      "hash": "sha256-Qn6Jw4Hj4Svhr+97SclbHh8il6zpaUNl2YAw+W9zQg8=",
      "url": "_framework/System.ComponentModel.Primitives.eotivnapz7.wasm"
    },
    {
      "hash": "sha256-wYi1dPW6vMdZfqA5R5/8asPOTpDTYqU7nCViLbMhvLY=",
      "url": "_framework/System.ComponentModel.TypeConverter.x4d9maevo7.wasm"
    },
    {
      "hash": "sha256-+Agcf5ODmGOlQrZjFnA8aUvS4GrMuO+9STI9gii3Wt8=",
      "url": "_framework/System.ComponentModel.o0bt2abfmk.wasm"
    },
    {
      "hash": "sha256-T11gpeE9bWEiaUZu1P/yt9BfQ2vUNyjIHUBKZLVddMI=",
      "url": "_framework/System.Configuration.b12keys70e.wasm"
    },
    {
      "hash": "sha256-E0JTds1IkVtGA1f4mJnBrcbaS4Q2B30mL52ccMiMf8s=",
      "url": "_framework/System.Console.byghioepvx.wasm"
    },
    {
      "hash": "sha256-GIJwftQRNikWF1RvRjUn1rcS2OGesGH1tfRArkLinzs=",
      "url": "_framework/System.Core.crs2w9a4bs.wasm"
    },
    {
      "hash": "sha256-hf6YOUn9SRa9D1R6a4QfBuC8H+J/VNwC46TbP6deErM=",
      "url": "_framework/System.Data.7l0iizrfot.wasm"
    },
    {
      "hash": "sha256-dfdfKru3HaThBupxbYUSMrUvFowLYcClUnNCsH3jlMY=",
      "url": "_framework/System.Data.Common.bgo75n328l.wasm"
    },
    {
      "hash": "sha256-JzVzXOoOTku9XUWOO1emR9P3DqOje01K5Dhib9hNRGQ=",
      "url": "_framework/System.Data.DataSetExtensions.x6usn7lchy.wasm"
    },
    {
      "hash": "sha256-AQBlWZgKXt+jX68NIlZiIJs7glHKv12MRp5wgMg0wzo=",
      "url": "_framework/System.Diagnostics.Contracts.zb5ovgp6rz.wasm"
    },
    {
      "hash": "sha256-y59odQsgIVG+NZw2PsRsIi0GrGpMY/pV0O8PHg1v5A4=",
      "url": "_framework/System.Diagnostics.Debug.pzraghcsxr.wasm"
    },
    {
      "hash": "sha256-XivkJZZaTNeflPHZ4EC9GO51pCyBAXpMQFrm777ZnqM=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.y8ylk8ocyk.wasm"
    },
    {
      "hash": "sha256-Kl4M3+1TGMC+K7b4Sr6vBxTMnX19QlSbDk/ci3F4b/c=",
      "url": "_framework/System.Diagnostics.FileVersionInfo.qf6phldvxs.wasm"
    },
    {
      "hash": "sha256-daRDl3Mc9bv8EEzzzKyblnQB+jEUDMuPwyN1kKL7YOc=",
      "url": "_framework/System.Diagnostics.Process.j6qkqs1xs6.wasm"
    },
    {
      "hash": "sha256-j4zlxg4q78gwEUo3Qx5RlaCBBR+kNDW2sOfguhrtfoA=",
      "url": "_framework/System.Diagnostics.StackTrace.zzgq407zst.wasm"
    },
    {
      "hash": "sha256-UFUL+alEr9O+yhLbkv//ZXtmZ2X0Os5sKSJp6JoUnjQ=",
      "url": "_framework/System.Diagnostics.TextWriterTraceListener.k3ba8zyfyp.wasm"
    },
    {
      "hash": "sha256-KkBnCR7G5FBX8tGlCinYJ4TSPYcLMU6ueTcbleZrZQY=",
      "url": "_framework/System.Diagnostics.Tools.awyyza3767.wasm"
    },
    {
      "hash": "sha256-pDL5LZSQ4CMsJxVWxbHLxaP4Q+MqkGjrBdMx6fJZGV0=",
      "url": "_framework/System.Diagnostics.TraceSource.w5t42xm4f8.wasm"
    },
    {
      "hash": "sha256-YxFrREqUafoKZ53mdMUG3HfbQumm17/vd0TvU1vHKSo=",
      "url": "_framework/System.Diagnostics.Tracing.zw8dj8hqv5.wasm"
    },
    {
      "hash": "sha256-KIfHUPIfDR6Ywkzl7rTWpqQSK79Audc8HtsbuHMtWfk=",
      "url": "_framework/System.Drawing.Primitives.cfbgr8gzc9.wasm"
    },
    {
      "hash": "sha256-+O9fNPcx8KB8jege3YahTq+/iuzNuO9UYKoQoMoyBf4=",
      "url": "_framework/System.Drawing.wemiyntni6.wasm"
    },
    {
      "hash": "sha256-TGFyS+jFkDen9z1YA9ldvjblDloMLSR0JVkIG939e2c=",
      "url": "_framework/System.Dynamic.Runtime.83wdfbg9dk.wasm"
    },
    {
      "hash": "sha256-yEnDGI2Y7GNzqmaJlxVvVTKrhOn9Fiv7zaUPLF0AEMM=",
      "url": "_framework/System.Formats.Asn1.wu3h4anva6.wasm"
    },
    {
      "hash": "sha256-T3/MNIaoKAHoohN5fH2dQ2FzhVxogaA/TiUyec/eY6c=",
      "url": "_framework/System.Formats.Tar.hgqfxjarhi.wasm"
    },
    {
      "hash": "sha256-EpHMe6nGJBxqyFqYIGjdi3Hjp2wlWJYEDalWUgFyrms=",
      "url": "_framework/System.Globalization.Calendars.ygja8e5f6z.wasm"
    },
    {
      "hash": "sha256-gyUasIzIw5fxDNrNSl/l2mSZwREFh9TSWjpz+SZgn+I=",
      "url": "_framework/System.Globalization.Extensions.lymlf1y54s.wasm"
    },
    {
      "hash": "sha256-JKy0P8bL3ZXo+gNPiaH/NkV9OMY2tYcCRWKkHs2LZ24=",
      "url": "_framework/System.Globalization.wn8krsslap.wasm"
    },
    {
      "hash": "sha256-3DvgyPsIGsiXu7hi4qXNzJr8iMJXoP3WSCZMfu0IC7c=",
      "url": "_framework/System.IO.Compression.Brotli.01wsvlce97.wasm"
    },
    {
      "hash": "sha256-A8kP6Pr6BKlGCtTFieHlCv5LuXACTAgDNsq3Fbb5uP8=",
      "url": "_framework/System.IO.Compression.FileSystem.fhhysos6ne.wasm"
    },
    {
      "hash": "sha256-8Waqn+/oBMyLZhHMdJDpr/uGZbXrfXDNtxwUGqx9LVg=",
      "url": "_framework/System.IO.Compression.ZipFile.b550bh7d4o.wasm"
    },
    {
      "hash": "sha256-P6qVNLsMSy3fbCkBUcAdoRNN74iTNJfBw2g+5HXd+lY=",
      "url": "_framework/System.IO.Compression.xga7hhx237.wasm"
    },
    {
      "hash": "sha256-qAKG1N95IVYn+7YBdwFlK6AXkMSGyWWr2ZlPSTUNG4E=",
      "url": "_framework/System.IO.FileSystem.AccessControl.gaf5qnpqkp.wasm"
    },
    {
      "hash": "sha256-eMXm6btJQ0QFaiKzUi/3XgyFgVfes482cbVhEnDJtFw=",
      "url": "_framework/System.IO.FileSystem.DriveInfo.sbt0tte66b.wasm"
    },
    {
      "hash": "sha256-DyDwUHL8mFAr69NKTyG1JY+OKNWB/JMGGX5a1uONPSU=",
      "url": "_framework/System.IO.FileSystem.Primitives.rhlpjpj7v7.wasm"
    },
    {
      "hash": "sha256-pCK6jzW5QjGcxz9ZG2C7fd4UpJANzHMigB3St6qc4zw=",
      "url": "_framework/System.IO.FileSystem.Watcher.c0tiebun14.wasm"
    },
    {
      "hash": "sha256-mkxAv0gjDBDMNzIy5+IDgvmTAAxg6TMquTT7e65g1F8=",
      "url": "_framework/System.IO.FileSystem.qjunxa5xpz.wasm"
    },
    {
      "hash": "sha256-QH3skcz0NjYVmE62qspNQN3f+OQh2dtS1KnGfOJrzPo=",
      "url": "_framework/System.IO.IsolatedStorage.st1kzda9co.wasm"
    },
    {
      "hash": "sha256-VctFxV2zTysc44Ik9MNnaVcYNGKIW1qRNBL8SDUp6Hc=",
      "url": "_framework/System.IO.MemoryMappedFiles.dud9xjr6ji.wasm"
    },
    {
      "hash": "sha256-i8phnvyiXxVXX07M/rZ9kqp+tT0XUh8HhUY6SEVyzNw=",
      "url": "_framework/System.IO.Pipelines.7hyknmpn75.wasm"
    },
    {
      "hash": "sha256-W1cQpoAbaGvRrijYQSg2TyQyEVoLz/l5hRw9DqieYnA=",
      "url": "_framework/System.IO.Pipes.AccessControl.hhnvgw5lgh.wasm"
    },
    {
      "hash": "sha256-mcsaGmJhcq4USe1jy18IW+3lrRfmIb5i4tG0UXexdZ8=",
      "url": "_framework/System.IO.Pipes.hiwotp9hyv.wasm"
    },
    {
      "hash": "sha256-oJdJc74VKlJiM9z++KKgsotHg/xbtOjsZYLtb71Z1+k=",
      "url": "_framework/System.IO.UnmanagedMemoryStream.ww8ebi8a3j.wasm"
    },
    {
      "hash": "sha256-0GUrSc5JU1BwifLiLKAvrLtnHTQ0326AwH3nWSGfBDk=",
      "url": "_framework/System.IO.gc5ray86oq.wasm"
    },
    {
      "hash": "sha256-6863YqGj4DfRgk8BzWuGVMhjf6cQhnLkOKdmgekxdL4=",
      "url": "_framework/System.Linq.9ffwb85ft1.wasm"
    },
    {
      "hash": "sha256-/KJFrMqgH1odpFXwoeOCeh3/H+BUuIRessP96epMnp0=",
      "url": "_framework/System.Linq.AsyncEnumerable.07kzmng77i.wasm"
    },
    {
      "hash": "sha256-/YgHfGfGNUNpDMDLvZkLdUm+fQJr2Z4owh+alJuNNdU=",
      "url": "_framework/System.Linq.Expressions.hnnxjo0l2j.wasm"
    },
    {
      "hash": "sha256-xGr5NkI7XLhsN9qVA5cMhQhK+5PEgjwO48JxZ54Vrzc=",
      "url": "_framework/System.Linq.Parallel.glk2arw06k.wasm"
    },
    {
      "hash": "sha256-z15deuvyAEHCF08A9yc3pz20pHves4ClLhZPYmAH8AM=",
      "url": "_framework/System.Linq.Queryable.9agv5eul41.wasm"
    },
    {
      "hash": "sha256-+RLBpFjrVbIwTSKhINZrtdQDpOoyllgMXodgNRVBKbQ=",
      "url": "_framework/System.Memory.psbhtw4rwf.wasm"
    },
    {
      "hash": "sha256-CmNQV8d7i/N2YUw5XpKfN1E27LtiVieOrvNahwkKC3o=",
      "url": "_framework/System.Net.Http.Json.u38okk8pdw.wasm"
    },
    {
      "hash": "sha256-hcNBh17l4O1AcN1THVeQsGfx2deOoYtCFPwcMlq3kk8=",
      "url": "_framework/System.Net.Http.hprl4g0ei6.wasm"
    },
    {
      "hash": "sha256-hqGJmP41JWMkR7TG2ez2EzZ13OlLETn+PvzpFXFc5dc=",
      "url": "_framework/System.Net.HttpListener.a7w2mz50g1.wasm"
    },
    {
      "hash": "sha256-8PkwMPzbOS3W/TC69m45HCmtVxAE1uvQRC0VYWWhMRo=",
      "url": "_framework/System.Net.Mail.0oz2x1giz0.wasm"
    },
    {
      "hash": "sha256-LAy4wC5p8qDwFOu0prSL6MkS5g4O08aY5I0WMvIkedk=",
      "url": "_framework/System.Net.NameResolution.ofawvy3ec7.wasm"
    },
    {
      "hash": "sha256-NWlmqw8qxB0qPtlbA/GvrBctcRTgqY+Zaf6bVdfuYG4=",
      "url": "_framework/System.Net.NetworkInformation.5gv80uqpl0.wasm"
    },
    {
      "hash": "sha256-KeaB0vW9oRc8hKruISyUsCSwwOQ68YFwLuMS1R6mznY=",
      "url": "_framework/System.Net.Ping.1ac0k1f2o4.wasm"
    },
    {
      "hash": "sha256-iEzW5J4i+VrLj2ofIqaj7PdebFvDYzb840eVElD08K4=",
      "url": "_framework/System.Net.Primitives.k1ozvs2jbp.wasm"
    },
    {
      "hash": "sha256-XuzmMLvQZO8sKTt1ACxN/hnorHkoScx9nUq3dWseRZE=",
      "url": "_framework/System.Net.Quic.irg6mf6a29.wasm"
    },
    {
      "hash": "sha256-uYZXCdg3nBdou2fVQ+d9INkYBkrVuMb/ZZjVFyukAKI=",
      "url": "_framework/System.Net.Requests.90fz04w7mu.wasm"
    },
    {
      "hash": "sha256-rzC9R/FFg/smWZV+ycyRnXEYTJPkc5GkmVQDgrg9H8U=",
      "url": "_framework/System.Net.Security.jfw2oy4ger.wasm"
    },
    {
      "hash": "sha256-LMIsU3qDhpkP3ValJegxT6kBfpWDKcC/gQ4a/G5rUT8=",
      "url": "_framework/System.Net.ServerSentEvents.kyt6lsc4yl.wasm"
    },
    {
      "hash": "sha256-0kd6zNt6XAhErIL/JvnVb5WhQmLHGa7O4r9mOCaCdjY=",
      "url": "_framework/System.Net.ServicePoint.ut6twkdfba.wasm"
    },
    {
      "hash": "sha256-T7ORwtwaDvPyvlklTX3q3RjWlvkmZ8A2HYRYK2/0KMs=",
      "url": "_framework/System.Net.Sockets.x8v2el0sv6.wasm"
    },
    {
      "hash": "sha256-CGTR3Az6JZ3QB1MIohRXCX0XijTRS2df6yotlJI+dQQ=",
      "url": "_framework/System.Net.WebClient.czcdllfidj.wasm"
    },
    {
      "hash": "sha256-G/ogYmbW5rkKKaDXZXzfYVKw/ut2mxdaAm/2uHDWLq0=",
      "url": "_framework/System.Net.WebHeaderCollection.bce2110s0r.wasm"
    },
    {
      "hash": "sha256-cQ63t0+pxlovMwoEf1eqjZCs/Fgvrc44qksU+tHkouE=",
      "url": "_framework/System.Net.WebProxy.5be8kwoend.wasm"
    },
    {
      "hash": "sha256-6ymXDNwxS1yC+D4brRafFvGYCxXoQTIAqZ4b7pvxRXY=",
      "url": "_framework/System.Net.WebSockets.Client.przg52xxg4.wasm"
    },
    {
      "hash": "sha256-a3n+jxPSgMa3cSRmppA6kGgWreYux0/j+j/o+SV5jmo=",
      "url": "_framework/System.Net.WebSockets.xlwui9bnh8.wasm"
    },
    {
      "hash": "sha256-xpFdoBA8uvHsmDNfY4Q+voDkqhoRWL/OL9ocN280cEI=",
      "url": "_framework/System.Net.m966t71d0p.wasm"
    },
    {
      "hash": "sha256-cZP5c7btHw6ZzifSUD/sdZnk7/ClXBYaxZWVfagmZeI=",
      "url": "_framework/System.Numerics.Vectors.z7brvfqdcr.wasm"
    },
    {
      "hash": "sha256-lgwAOy/jT/jYpbLMPsynoGm6/673OpvPVIchOAz3osA=",
      "url": "_framework/System.Numerics.ag24ir3prp.wasm"
    },
    {
      "hash": "sha256-q1FqdH7yefTzxmYdAPicRkU2dE2tzuvMAvKBX/JcDD0=",
      "url": "_framework/System.ObjectModel.xh1vpnmjgs.wasm"
    },
    {
      "hash": "sha256-dZcjaLZIVjaf6xlQHMhiQDLIcjUdoNb5lmg3A/A9l94=",
      "url": "_framework/System.Private.CoreLib.juov5x1i7w.wasm"
    },
    {
      "hash": "sha256-+cHeSmTAWB13XR/X/DU4LuHBLH7FWvDN/6yrao9HpBM=",
      "url": "_framework/System.Private.DataContractSerialization.l9evwq6x3r.wasm"
    },
    {
      "hash": "sha256-RJyqxBvRVgbmsbfYJ4rz7biALfDCoJ2UNIrstErC0u0=",
      "url": "_framework/System.Private.Uri.w7q0j7zx27.wasm"
    },
    {
      "hash": "sha256-Z/mvH93p1uq4fc1w03Q8lFU7xDrlJpFSQAF5x/K7dU8=",
      "url": "_framework/System.Private.Xml.Linq.1ei6wtrgkp.wasm"
    },
    {
      "hash": "sha256-csu8wJjFJmfh9RQaxG7wdCWJYmyYrsITHzGDL20yF4o=",
      "url": "_framework/System.Private.Xml.q1h1022344.wasm"
    },
    {
      "hash": "sha256-yJsdOUe+DYOubIee0JxJiMsxjdzLOXzZMn30z7v66QE=",
      "url": "_framework/System.Reflection.DispatchProxy.g2yz9xctp2.wasm"
    },
    {
      "hash": "sha256-OY62vl/YQB4MpLAWUX6Bx8vXm2f42kXNsemwVTycy7I=",
      "url": "_framework/System.Reflection.Emit.1ir4e7atax.wasm"
    },
    {
      "hash": "sha256-LKeb+EdwDOLgj5jIqAt7/1UzqUXZKoN4ccNGW0wL560=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.kwkwfmyend.wasm"
    },
    {
      "hash": "sha256-6vyrs19B7w9dGqSInB8X+1zDKkZjRGQXOBMPMF+whIY=",
      "url": "_framework/System.Reflection.Emit.Lightweight.2uboz65mda.wasm"
    },
    {
      "hash": "sha256-M0GewU6PblUI8DcaT7PKvFGAFy46cFUJMfKWcMs1j1I=",
      "url": "_framework/System.Reflection.Extensions.ryls3wcjtu.wasm"
    },
    {
      "hash": "sha256-ik4C5OQWIByvdp3BJr4ZAvhYrVAmczfJg996oxb5iRg=",
      "url": "_framework/System.Reflection.Metadata.685kento59.wasm"
    },
    {
      "hash": "sha256-g45DkpgeojTNQ26Ui2ivG0G4SCGpd9ul+Y7R3MfshQU=",
      "url": "_framework/System.Reflection.Primitives.xfo3jok9qj.wasm"
    },
    {
      "hash": "sha256-3VlNajP6ff9vQv/QYTVh7KOvXJygqVKDmGdnrKJA6Ss=",
      "url": "_framework/System.Reflection.TypeExtensions.do7opdhcum.wasm"
    },
    {
      "hash": "sha256-4cGtWeTBsnjb3aOzNjh6scV1i+F1ljcrgwQfFkwfG40=",
      "url": "_framework/System.Reflection.rlpuhk2fom.wasm"
    },
    {
      "hash": "sha256-QMaaA8pzSeI0UVcfJ2C3HpDn/pTDfk/eHXVu2jg4W1w=",
      "url": "_framework/System.Resources.Reader.4jh2hk8ou1.wasm"
    },
    {
      "hash": "sha256-ESS3qolG2qdzo+jTNQA/TLzb78BsEUegO3ysF2X/Y4Q=",
      "url": "_framework/System.Resources.ResourceManager.l74nv8dd2y.wasm"
    },
    {
      "hash": "sha256-QF8xaglb5gAi5WxshSa01YnbT+HIuu48iOaW8ACFb/o=",
      "url": "_framework/System.Resources.Writer.0w0j4onmez.wasm"
    },
    {
      "hash": "sha256-2fnX1oqwXtZiditXWXvyfeNQ991HeEhpDNCAbNsUx9o=",
      "url": "_framework/System.Runtime.CompilerServices.Unsafe.psp9r1rjx3.wasm"
    },
    {
      "hash": "sha256-/wivVVMBx+KQpVXpvy2D9Kg+1KiyxcXjK+yP3znQhnQ=",
      "url": "_framework/System.Runtime.CompilerServices.VisualC.ddaiepa6v6.wasm"
    },
    {
      "hash": "sha256-YW/SHM9hXOfEWgV/EZDdu2WIw2v8BVweWJ5rBY/3TTw=",
      "url": "_framework/System.Runtime.Extensions.7mo8aanhcl.wasm"
    },
    {
      "hash": "sha256-o+pR36TOd2wxkFe3d8fVj8Pabv2VZGXCLg+VPh1IY/A=",
      "url": "_framework/System.Runtime.Handles.302mjdnyau.wasm"
    },
    {
      "hash": "sha256-RxeSFjsuk6C7ECNNbfqkoLjluC8iflL3DB2R/2ICn8I=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.1qlb6weis6.wasm"
    },
    {
      "hash": "sha256-hcjUpnUQtPH9m4OI3sZWZuy9LnncUvAtwOYKZri6zq8=",
      "url": "_framework/System.Runtime.InteropServices.RuntimeInformation.7hdhpo4imj.wasm"
    },
    {
      "hash": "sha256-vR9sPZnV+edEk044pKra/H9KvrC3ReWea8MM6eYjTYA=",
      "url": "_framework/System.Runtime.InteropServices.dgvqyfg0pe.wasm"
    },
    {
      "hash": "sha256-tMYK4S9nyrcF3OBc4a0C9kcUX6OE1qYRu/l/Wufz9EI=",
      "url": "_framework/System.Runtime.Intrinsics.4opvn70127.wasm"
    },
    {
      "hash": "sha256-IJqvBpg6PV2jr1MidEJA2NptmQBDH4PxOwnudXzF0fA=",
      "url": "_framework/System.Runtime.Loader.g8rkjfh4qm.wasm"
    },
    {
      "hash": "sha256-nZ9wPx+0oBT8ILZR72gGp89L+D3u3bVDJPT7pIQv8F8=",
      "url": "_framework/System.Runtime.Numerics.v1ulx56ak0.wasm"
    },
    {
      "hash": "sha256-Jx8GlV47mhMiNlPp3wpJQ8iezasfZy4AFS6S+r4ThNg=",
      "url": "_framework/System.Runtime.Serialization.Formatters.rvz6whau2l.wasm"
    },
    {
      "hash": "sha256-ojAOZ21pR1AzC5H27z+nt2J4mKuqSGtzHXbHMfae5Kw=",
      "url": "_framework/System.Runtime.Serialization.Json.qudur1ne02.wasm"
    },
    {
      "hash": "sha256-iZiMFOaA0zvnRKFXWXKyGUSfMXoMlvSTDPyu/ZYxa/g=",
      "url": "_framework/System.Runtime.Serialization.Primitives.j92gsjj8kn.wasm"
    },
    {
      "hash": "sha256-jkC8gqDFuNptgkezc3tz3BXUDz0LOP2hHdMXLXU4A2Q=",
      "url": "_framework/System.Runtime.Serialization.Xml.ukymcjvxx5.wasm"
    },
    {
      "hash": "sha256-gfkNnDMRhtC/eV5d7S7dzKs6oGz0A95oLDx0PGmiYzU=",
      "url": "_framework/System.Runtime.Serialization.z7e61m03nm.wasm"
    },
    {
      "hash": "sha256-O2Z4wMF9THG6aFh0s5Y6DR9aNRClszGLH0SsektBg9U=",
      "url": "_framework/System.Runtime.tendud3ylb.wasm"
    },
    {
      "hash": "sha256-8MiHiGyFi6Au8xRdrJwRD5mdQZFzL7noN35GE7iKydk=",
      "url": "_framework/System.Security.4vhqo5un91.wasm"
    },
    {
      "hash": "sha256-6FP/EmubPWfB4Ho6x0CBkmUPKAmjIloGcIYVEXitWh4=",
      "url": "_framework/System.Security.AccessControl.cv3mvcgnqt.wasm"
    },
    {
      "hash": "sha256-e/G5sWQc/d0vdxES+8ljo1iJA+mPXKONKZl9V1OU0gs=",
      "url": "_framework/System.Security.Claims.vv0su8gg3e.wasm"
    },
    {
      "hash": "sha256-TpNTuXxlGfc/5+pJYitTfDCK7AgCt0OnDj44SMn4QSs=",
      "url": "_framework/System.Security.Cryptography.Algorithms.u07jl1h8ni.wasm"
    },
    {
      "hash": "sha256-dXkPSuaLu+/R72TqK3HP8g4NPdHFp/TwloOyWqHAzXk=",
      "url": "_framework/System.Security.Cryptography.Cng.nx9df96u5j.wasm"
    },
    {
      "hash": "sha256-Ek325qFgVLGIMfnhltzDbYR+iN77sxnUe9YINbIK4Ew=",
      "url": "_framework/System.Security.Cryptography.Csp.iv0qssebou.wasm"
    },
    {
      "hash": "sha256-Ar3GH8OCsjvdksghGoEfblenEdgWEJLjZQOxi/cJW7A=",
      "url": "_framework/System.Security.Cryptography.Encoding.yvcfg16da3.wasm"
    },
    {
      "hash": "sha256-Veuv5yjWf20hAREWWjzBwzOwwQ89oZFBTGrpLjpSSfY=",
      "url": "_framework/System.Security.Cryptography.OpenSsl.1t0tq6hwlx.wasm"
    },
    {
      "hash": "sha256-4ZhdozjdVjIT1N21cSDLRxg3N9BycjEZzFDoBafvxyk=",
      "url": "_framework/System.Security.Cryptography.Primitives.lvrn81knoi.wasm"
    },
    {
      "hash": "sha256-uNjKBp3dK985Qoxa/EeVMQFVO8Tty4GpS2FmXW3yo/0=",
      "url": "_framework/System.Security.Cryptography.X509Certificates.sjrlqg0zgl.wasm"
    },
    {
      "hash": "sha256-KxfMS6/n71XmcYW2DIVVEGfu7TdNOp7Ipht//dLLVbQ=",
      "url": "_framework/System.Security.Cryptography.d6btj6o3of.wasm"
    },
    {
      "hash": "sha256-//bfJMPEutxUoyncg8HhD318cKvqxBNMeDjFLf8CnIw=",
      "url": "_framework/System.Security.Principal.Windows.rdh8dkjzrz.wasm"
    },
    {
      "hash": "sha256-GGPWQO9V2/MZq00yPykTbnQhtQJthnVZOyte5kRpds8=",
      "url": "_framework/System.Security.Principal.cb0msvc61t.wasm"
    },
    {
      "hash": "sha256-CIvvtUXtrv45XtyhoHJFfSLJT5CZeQ08JrqEWkPhU0U=",
      "url": "_framework/System.Security.SecureString.kx9zmavdgn.wasm"
    },
    {
      "hash": "sha256-ROvgJE3FXPPa2fX2qUEjVXD+jL1pGbKeDk9AOvp9huM=",
      "url": "_framework/System.ServiceModel.Web.ol7pik4njh.wasm"
    },
    {
      "hash": "sha256-pfO/vjq/gY0nSPKJHwstdvgqHhV1rzFXb+O9NuVs0Bc=",
      "url": "_framework/System.ServiceProcess.x9ceibitb3.wasm"
    },
    {
      "hash": "sha256-w6TbPH0ZGsXE2moaDxCXWkpHk1f6eRSadPLaZWA5Iis=",
      "url": "_framework/System.Text.Encoding.CodePages.xr9jzwuhbs.wasm"
    },
    {
      "hash": "sha256-VUgVzZH1+UB5A9+N8SyKKU2kDlMc7ktp+GVVtdupM4w=",
      "url": "_framework/System.Text.Encoding.Extensions.p7ksnf6eqq.wasm"
    },
    {
      "hash": "sha256-2EQFlGI4BVCJulJd3F2h6T0EtsGSlAK4WutHAaLBSt0=",
      "url": "_framework/System.Text.Encoding.gylgsn1uaa.wasm"
    },
    {
      "hash": "sha256-0JZTS0SdWRSnmJkSJLLPyMBE6ssKLcEpBC0qk9MxcWM=",
      "url": "_framework/System.Text.Encodings.Web.43wbm7qo0m.wasm"
    },
    {
      "hash": "sha256-gUHsAryISczen4HIrfQZYvKXlvqHArroVlp47LwKsI0=",
      "url": "_framework/System.Text.Json.3fm0130zj1.wasm"
    },
    {
      "hash": "sha256-8WLhygNpdDdZRKESO9vTJRsjVt2R0snj7hpK+nxQLcI=",
      "url": "_framework/System.Text.RegularExpressions.ljb2w7634m.wasm"
    },
    {
      "hash": "sha256-kwcVWB8hw0XHrw4G8Mrm4KqJ4vSayz7vr+gX30kCgQ0=",
      "url": "_framework/System.Threading.91g5sfq1sa.wasm"
    },
    {
      "hash": "sha256-TURKqENVwrbM9Of4Z24ldBYWqJ4qqwcfzgL09OMsV8Y=",
      "url": "_framework/System.Threading.AccessControl.joce0p84gc.wasm"
    },
    {
      "hash": "sha256-AtTq1bOyaqRXW3xuGVm1PheL6CibX1BnOBDgKNsXfAc=",
      "url": "_framework/System.Threading.Channels.mnnp4ji3ib.wasm"
    },
    {
      "hash": "sha256-zPxihETW4rxyYvtSqOH7eGV7sL6x+K1kXooiVIorALQ=",
      "url": "_framework/System.Threading.Overlapped.wbup7sojf3.wasm"
    },
    {
      "hash": "sha256-Pk90IHCNeRzSXG6n9nlT3ihnQGCku340uU0+ZnAXDFI=",
      "url": "_framework/System.Threading.Tasks.6fasd8si7q.wasm"
    },
    {
      "hash": "sha256-SZnwVSHdUFrvYtzjxWYiGWiLkTfmmue94t4r468G0hg=",
      "url": "_framework/System.Threading.Tasks.Dataflow.n4t9zieonm.wasm"
    },
    {
      "hash": "sha256-3FF6cfQYZq7UMq9eI4Vy3ToMAD1y0PsovcABxyqmDMk=",
      "url": "_framework/System.Threading.Tasks.Extensions.wdrme7fxwz.wasm"
    },
    {
      "hash": "sha256-HEO4P9fPWflNhGS7S5ogWuNporpRa989CAdNPnKdT28=",
      "url": "_framework/System.Threading.Tasks.Parallel.03vnuen8lc.wasm"
    },
    {
      "hash": "sha256-K/SEm7oD2cgkqdb0FqP2OF2yURyQZxWKIrCh0bPnP6E=",
      "url": "_framework/System.Threading.Thread.jil5gq8n2g.wasm"
    },
    {
      "hash": "sha256-NLdsXbdWt2j2Y+/30zy1oMNk356H34xyLFkCswbyTUw=",
      "url": "_framework/System.Threading.ThreadPool.w7nx9n33c3.wasm"
    },
    {
      "hash": "sha256-rf5gtbmNbLTLLcbwBqPUIeShwXl+3lP7ueMxCrWRxwo=",
      "url": "_framework/System.Threading.Timer.vpz28qnb8r.wasm"
    },
    {
      "hash": "sha256-oUhRiyXkqQs0EiVprs0RQ+8CePbZKaFjf5RxH2xcnEs=",
      "url": "_framework/System.Transactions.Local.tlh6ezjhx4.wasm"
    },
    {
      "hash": "sha256-UVboyp/gChJBtiHJoU2syJgrqsXMBkjK3LQ+0K7bMqo=",
      "url": "_framework/System.Transactions.xg3z6p9c5x.wasm"
    },
    {
      "hash": "sha256-+5oflbIHf80nBKk70uUrcDX4T1jtWztPrRb4Uzy1ppY=",
      "url": "_framework/System.ValueTuple.juzeeowza8.wasm"
    },
    {
      "hash": "sha256-5bmefWDXiyMsv2v2SXYvmh6NevqHISA/JxP8Zy8WdMs=",
      "url": "_framework/System.Web.HttpUtility.50ukl0vvlp.wasm"
    },
    {
      "hash": "sha256-YU5wgaEMuLGNtM/hJuBBMZLDAEe9XA6SO5T3QUkwQtc=",
      "url": "_framework/System.Web.nquguxbga8.wasm"
    },
    {
      "hash": "sha256-fwiXt1le8pwi4fZGHYYZFmGLr8hOoGddT8Cxsl962z0=",
      "url": "_framework/System.Windows.7my52aupxf.wasm"
    },
    {
      "hash": "sha256-7lUvBPzNLfuFjVfyWHyiwLlk3aLGpj7lyXW28c298II=",
      "url": "_framework/System.Xml.Linq.mr3gbysv2k.wasm"
    },
    {
      "hash": "sha256-s3t61Bpa+mm2RwSfcVTSd7lSmOBaEkLGIsI4GWNGeOU=",
      "url": "_framework/System.Xml.ReaderWriter.5aewgdxgx5.wasm"
    },
    {
      "hash": "sha256-XHihnSxTt35ijX8Pyf6SGdANTNE0q1hx+N9LfRRKLQQ=",
      "url": "_framework/System.Xml.Serialization.895vgbnzvk.wasm"
    },
    {
      "hash": "sha256-CNhPG60MleDV2kvMK3KewekvnzPBkvUF20eeJqstPmg=",
      "url": "_framework/System.Xml.XDocument.gawed0m0dk.wasm"
    },
    {
      "hash": "sha256-/IC9Cu68swNOSRQp7Nmd/Tfg0kO4WTFHMd1qRICifew=",
      "url": "_framework/System.Xml.XPath.XDocument.8d6fv5kfwc.wasm"
    },
    {
      "hash": "sha256-F6ZgWE5PKQkCYDtRX09jJ4AMDZp0pTvIRHlxSi1NqBo=",
      "url": "_framework/System.Xml.XPath.rzdhxhia4c.wasm"
    },
    {
      "hash": "sha256-cM7mVS+LOzJRS/CvfzKK7OWognXFCUxKoch4KOVAgf0=",
      "url": "_framework/System.Xml.XmlDocument.sleio7elqk.wasm"
    },
    {
      "hash": "sha256-SbB7pfP1ufQmve5TnRDHPvyZ37xbZxR96BMMm+gC1fc=",
      "url": "_framework/System.Xml.XmlSerializer.dzxtf0jve0.wasm"
    },
    {
      "hash": "sha256-pxzdRzNLctL4GGW80wT7UmIvwENVVwKzL2R1tkAzCnY=",
      "url": "_framework/System.Xml.dvbhh7ypsi.wasm"
    },
    {
      "hash": "sha256-A9VpSuOMfnHHYzC2v9VAe3tZo4b5fafKT2VUs6RAPio=",
      "url": "_framework/TEAprendo.Client.d8lqletxhe.wasm"
    },
    {
      "hash": "sha256-k7OsxRAQ3H1qKtWafTXFgwiKbrthMqjOmUhuFDWtFVo=",
      "url": "_framework/TEAprendo.Client.nvyg72zfft.pdb"
    },
    {
      "hash": "sha256-qGdYzdRUD7OayLRUx5y7/OfSdMC/WtE67lTT5kj7xI8=",
      "url": "_framework/TEAprendo.Contracts.8or1ipc9iq.wasm"
    },
    {
      "hash": "sha256-V4+53wEJ4NC4nYssUJ/RAE0yDzmn1fb6JQxWhvrwSEQ=",
      "url": "_framework/TEAprendo.Contracts.l5e8v2vrhf.pdb"
    },
    {
      "hash": "sha256-nFB7Od4QfJbsCJHdZ3GNVn52dUv3k1CWEcVs7gnS4UM=",
      "url": "_framework/WindowsBase.sai7rvg6jy.wasm"
    },
    {
      "hash": "sha256-lDXsDYFgm62F+YUvxES7IOTCXYpiHpU3uR45YdC6mq4=",
      "url": "_framework/blazor.webassembly.w3qd1tpl0e.js"
    },
    {
      "hash": "sha256-mLG7a3tlP49R36AUCfTo0e8FSvkuP68htQkaN9+cLJo=",
      "url": "_framework/dotnet.js.map"
    },
    {
      "hash": "sha256-gQbHHzCnWx8iDOC65EKbql7bEltJkfao7lmkAbIRajw=",
      "url": "_framework/dotnet.native.puryxhmhq9.js"
    },
    {
      "hash": "sha256-pqkc+YDwRTSgmuWJlAiNJayjN0YQFu94A84NGzuA12Q=",
      "url": "_framework/dotnet.native.u31nt9bth6.wasm"
    },
    {
      "hash": "sha256-ItTH5BnngjQiCIjJnlUm2jKeJnpmclkmoVbl0b3nBlU=",
      "url": "_framework/dotnet.qysidhil66.js"
    },
    {
      "hash": "sha256-BTr7Py30c5oSFYkme7Ky/+x9fmHVYPVYGiVSjnafzxE=",
      "url": "_framework/dotnet.runtime.js.map"
    },
    {
      "hash": "sha256-SOUHEQ3FhDAibBSR2u90NWZpoBjPuWRmH0BAATUlhJU=",
      "url": "_framework/dotnet.runtime.web2r9gqbh.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-Sek1w6zfsp+mdfTY+0a9BIJVfwMWPqO89TVmyiwd4sU=",
      "url": "_framework/mscorlib.j53nj9v82n.wasm"
    },
    {
      "hash": "sha256-oo0Rj85FzuT7F2L74T+91kWWN2QGMHIrHiP/zI1NMI0=",
      "url": "_framework/netstandard.6qjyqs9cni.wasm"
    },
    {
      "hash": "sha256-yRJ49z3y3rHi/X6jpbhaZS6+RJBCP3/2qRNriPwlJ3c=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-m3FkIe/G5jsgAAHtd74kAP/aFyjMCU9oifRrChWUpyw=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-QWmrzBhUOGeYXVQ5X/L8YRJEbn4yp6CTiceBcMTX0Qg=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-BSudNoERRnZi8VkT7Z7SdkRHU7/syl2FDF+PSQq0BS8=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-LZ3YSIvDIilWUOZ2b1Hj5Hzum6vEF71KPnetoM6fspc=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-wIdG8lWZMdLaWPbf+qT/u/yV544RYAragaptY38jSW8=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-5xOkUT1sQwwyESieLDMJjxNQEAiqKoE7ziDD13psK3c=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-TvC8H8WjuHA5e0miejGSgbnrzyNt9eSg7OEHZEYstAk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-G3dD3kYmxoDaNbSMhKBb3RWmNJon7sl/GGdK1p5bXVw=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-9AmcQvaRpm/zQeIXrqc79T9I6Cq5q2AHRtKL/432TSc=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-0Zbn58ulonNXO6K1HFirxMdEh1TWFZQV3SC90G5b1OA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-MigawlgtbIcVRyOcBu04CwEn45bbsh/qO98BKaNcytw=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
